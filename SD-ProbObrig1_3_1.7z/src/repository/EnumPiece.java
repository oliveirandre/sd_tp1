package repository;

/**
 *
 * @author Andre e Joao
 */
public enum EnumPiece {
    Engine,
    Brakes,
    Wheels
}
