/**
* This package is responsible to initialize every entity and shared area.
* Furthermore, it also creates a log describing the problem.
*/

package repository;
