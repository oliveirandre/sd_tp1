/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shared;

/**
 *
 * @author andre
 */
public interface ICustomerP {

    public void parkCar(int id);

    public void collectCar(int id);

    public int findCar();

    public void backToWorkByCar();

    public void returnReplacementCar(int id);
}
