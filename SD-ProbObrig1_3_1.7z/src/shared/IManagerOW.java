package shared;

/**
 *
 * @author andre e joao
 */
public interface IManagerOW {

    public boolean phoneCustomer(int id);
}
