package shared;

import repository.Piece;

/**
 *
 * @author andre e joao
 */
public interface IManagerSS {

    public int goToSupplier(Piece partNeeded);
}
