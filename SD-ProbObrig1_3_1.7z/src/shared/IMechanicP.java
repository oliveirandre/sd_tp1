package shared;

/**
 *
 * @author andre e joao
 */
public interface IMechanicP {

    public void getVehicle(int id);

    public void returnVehicle(int id);
}
