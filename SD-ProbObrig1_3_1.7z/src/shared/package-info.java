/**
* This package contains the shared memory areas: lounge, park, repair area, supplier site and outside world.
*/

package shared;
